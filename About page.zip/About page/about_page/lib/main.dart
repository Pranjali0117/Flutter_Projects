import 'package:flutter/material.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'About',
          style: TextStyle(
            color: Colors.black,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Our Mission Section
            _buildSection(
              title: 'Our Mission',
              content:
                  'Our mission is to provide users with a comprehensive and reliable source of information on a wide range of topics. We strive to make knowledge accessible to everyone, fostering curiosity and lifelong learning.',
            ),

            const SizedBox(height: 32),

            // Background Section
            _buildSection(
              title: 'Background',
              content:
                  'This app was developed by a team of passionate individuals dedicated to creating a valuable resource for users seeking information. We believe in the power of knowledge to empower individuals and contribute to a more informed society.',
            ),

            const SizedBox(height: 32),

            // Contact Us Section
            _buildContactSection(),

            const SizedBox(height: 40),

            // Bottom Contact Icons
            _buildContactIcons(),
          ],
        ),
      ),
    );
  }

  Widget _buildSection({required String title, required String content}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          content,
          style: const TextStyle(
            fontSize: 14,
            height: 1.6,
            color: Colors.black54,
            letterSpacing: 0.3,
          ),
        ),
      ],
    );
  }

  Widget _buildContactSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Contact Us',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 12),
        RichText(
          text: const TextSpan(
            style: TextStyle(
              fontSize: 14,
              height: 1.6,
              color: Colors.black54,
              letterSpacing: 0.3,
            ),
            children: [
              TextSpan(
                text:
                    'If you have any questions, feedback, or suggestions, please don\'t hesitate to reach out to us at ',
              ),
              TextSpan(
                text: 'support@infoapp.com',
                style: TextStyle(
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                ),
              ),
              TextSpan(
                text:
                    '. We value your input and are committed to continuously improving our app.',
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildContactIcons() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildContactIcon(
          icon: Icons.home_outlined,
          label: 'Home',
          onTap: () {
            // Navigate to home
          },
        ),
        const SizedBox(width: 40),
        _buildContactIcon(
          icon: Icons.info_outline,
          label: 'About',
          isSelected: true,
          onTap: () {
            // Current page
          },
        ),
        const SizedBox(width: 40),
        _buildContactIcon(
          icon: Icons.mail_outline,
          label: 'Contact',
          onTap: () {
            // Navigate to contact
          },
        ),
      ],
    );
  }

  Widget _buildContactIcon({
    required IconData icon,
    required String label,
    bool isSelected = false,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: isSelected ? Colors.blue : Colors.grey.shade100,
              shape: BoxShape.circle,
            ),
            child: Icon(
              icon,
              color: isSelected ? Colors.white : Colors.grey.shade600,
              size: 24,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: isSelected ? Colors.blue : Colors.grey.shade600,
              fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}

// Usage example - Add this to your main.dart or routing
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'About Page Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Roboto', // or your preferred font
      ),
      home: const AboutPage(),
    );
  }
}

void main() {
  runApp(MyApp());
}
