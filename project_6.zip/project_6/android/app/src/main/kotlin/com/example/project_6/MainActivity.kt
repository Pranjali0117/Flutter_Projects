package com.example.project_6

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
