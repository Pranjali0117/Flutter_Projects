import 'package:flutter/material.dart';
import 'course_details_screen.dart'; // Import the Course Detail screen

class CoursesScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Courses')),
      body: ListView(
        children: <Widget>[
          ListTile(
            leading: Icon(Icons.book),
            title: Text('Flutter Basics'),
            subtitle: Text('Introduction to Flutter.'),
            trailing: Icon(Icons.arrow_forward),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => CourseDetailScreen(
                        courseTitle: 'Flutter Basics',
                        courseDescription: 'Introduction to Flutter.')),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.book),
            title: Text('Dart Language'),
            subtitle: Text('Learn Dart in depth.'),
            trailing: Icon(Icons.arrow_forward),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => CourseDetailScreen(
                        courseTitle: 'Dart Language',
                        courseDescription: 'Learn Dart in depth.')),
              );
            },
          ),
        ],
      ),
    );
  }
}