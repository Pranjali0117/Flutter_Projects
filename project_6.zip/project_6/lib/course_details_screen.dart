import 'package:flutter/material.dart';class CourseDetailScreen extends StatelessWidget {
  final String courseTitle;
  final String courseDescription;

  CourseDetailScreen({required this.courseTitle, required this.courseDescription});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(courseTitle)),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(courseTitle,
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text('Course Description',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(courseDescription),
            SizedBox(height: 20),            ElevatedButton(
              child: Text('Start Course'),
              onPressed: () {
                // TODO: Implement start course logic
              },
            ),
          ],
        ),
      ),
    );
  }
}