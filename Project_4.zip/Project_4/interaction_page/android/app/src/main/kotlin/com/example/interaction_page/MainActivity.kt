package com.example.interaction_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
